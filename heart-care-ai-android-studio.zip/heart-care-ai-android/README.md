# HEART CARE AI — Android starter project

This is an Android Studio project scaffold that packages the existing HTML prototype in a WebView. It is **not a built APK** and is **not a production medical app**.

## Build
1. Install Android Studio (with Android SDK Platform 35 and a compatible JDK).
2. Open this folder (`heart-care-ai-android`) in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Expected APK output after a successful local build: `app/build/outputs/apk/debug/app-debug.apk`.

## Current limitations
- Demo data is stored locally in the browser/WebView only.
- No backend, account/login, encrypted cloud health records, doctor verification, appointment service, video consultation, payments, Bluetooth device integration, validated medical AI, or family notification service is connected.
- Browser speech recognition may not work in Android WebView without native microphone permission and speech-service integration. Do not treat voice as implemented for production.
- SOS opens the phone dialer for 112; it does not silently place a call.
- The app does not predict heart attacks or replace medical professionals.

Before public release, add a secure backend, explicit consent and privacy controls, clinical validation and qualified medical oversight, verified doctors, compliant telemedicine/payment integrations, and device testing. For severe chest pain, breathlessness, fainting, or sudden serious symptoms, call India's emergency number 112.
